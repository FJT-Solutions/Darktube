// Dark Clips - Instagram Content Script (Universal Scanner, Continuous Accumulator & Auto-Miner)
(function () {
  const SCRIPT_NAME = 'DarkClips-Instagram';
  const DEFAULT_API_URL = 'https://darktube.fjt-solutions.com';

  // In-memory persistent map of all posts accumulated during this page session
  const accumulatedSessionPosts = new Map();
  let isAutoMining = false;
  let autoMineInterval = null;

  function showToast(message, isError = false) {
    try {
      const existing = document.querySelector('.dark-clips-toast');
      if (existing) existing.remove();

      const toast = document.createElement('div');
      toast.className = 'dark-clips-toast';
      if (isError) toast.style.borderLeftColor = '#ef4444';
      toast.innerHTML = `<span>${isError ? '⚠️' : '⚡'}</span> <span>${message}</span>`;
      document.body.appendChild(toast);

      setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transition = 'opacity 0.3s ease';
        setTimeout(() => toast.remove(), 300);
      }, 3500);
    } catch {}
  }

  async function getAuthAndApi() {
    return new Promise((resolve) => {
      try {
        chrome.storage.local.get(['darktube_api_url', 'darktube_token', 'darktube_user'], (res) => {
          resolve({
            baseUrl: res?.darktube_api_url || DEFAULT_API_URL,
            token: res?.darktube_token || null,
            user: res?.darktube_user || null
          });
        });
      } catch {
        resolve({ baseUrl: DEFAULT_API_URL, token: null, user: null });
      }
    });
  }

  async function sendToDarkClips(items, btnElement) {
    if (btnElement) {
      btnElement.classList.add('sending');
      btnElement.innerHTML = '<span>⏳ Enviando...</span>';
    }

    try {
      const { baseUrl, token, user } = await getAuthAndApi();
      const endpoint = `${baseUrl.replace(/\/$/, '')}/api/dark-clips/import`;

      const headers = { 'Content-Type': 'application/json' };
      if (token) headers['Authorization'] = `Bearer ${token}`;

      const list = Array.isArray(items) ? items : [items];

      const response = await fetch(endpoint, {
        method: 'POST',
        headers,
        body: JSON.stringify({
          platform: 'instagram',
          items: list,
          userId: user?.id || null
        })
      });

      const result = await response.json();

      if (result.success) {
        if (btnElement) {
          btnElement.classList.remove('sending');
          btnElement.classList.add('sent');
          btnElement.innerHTML = '<span>✅ Enviado ao Dark Clips!</span>';
          setTimeout(() => {
            btnElement.classList.remove('sent');
            btnElement.innerHTML = `
              <svg class="dark-clips-icon" viewBox="0 0 24 24"><path d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
              <span>Dark Clips</span>
            `;
          }, 3000);
        }
        showToast(`${list.length} post(s) enviado(s) ao Dark Clips com sucesso!`);
      } else {
        throw new Error(result.error || 'Erro ao importar');
      }
    } catch (err) {
      console.error('[DarkClips] Erro ao enviar:', err);
      if (btnElement) {
        btnElement.classList.remove('sending');
        btnElement.innerHTML = '<span>❌ Falha</span>';
        setTimeout(() => {
          btnElement.innerHTML = `
            <svg class="dark-clips-icon" viewBox="0 0 24 24"><path d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
            <span>Dark Clips</span>
          `;
        }, 3000);
      }
      showToast('Falha ao conectar com https://darktube.fjt-solutions.com', true);
    }
  }

  function parseMetricNumber(str) {
    if (!str) return 0;
    const clean = String(str).replace(/\./g, '').replace(/,/g, '.').toLowerCase();
    if (clean.includes('k') || clean.includes('mil')) {
      return Math.round(parseFloat(clean) * 1000) || 0;
    }
    if (clean.includes('m') || clean.includes('mi')) {
      return Math.round(parseFloat(clean) * 1000000) || 0;
    }
    const digits = String(str).replace(/\D/g, '');
    return digits ? parseInt(digits, 10) : 0;
  }

  function getPageProfileInfo() {
    const pathParts = window.location.pathname.split('/').filter(Boolean);
    const notProfiles = ['explore', 'reels', 'direct', 'stories', 'p', 'reel', 'tv'];
    if (pathParts.length > 0 && !notProfiles.includes(pathParts[0])) {
      const handle = `@${pathParts[0]}`;
      const headerTitle = document.querySelector('header h2, header h1, main h2, main h1, h2')?.textContent?.trim();
      const avatarImg = document.querySelector('header img, img[alt*="perfil"], img[alt*="profile"]')?.getAttribute('src') || '';
      return {
        handle,
        name: headerTitle || pathParts[0],
        avatar: avatarImg
      };
    }
    return { handle: '@instagram', name: 'Instagram Creator', avatar: '' };
  }

  function extractModalPostData(container) {
    try {
      const video = container.querySelector('video');
      const currentUrl = window.location.href;
      const profileInfo = getPageProfileInfo();

      let authorHandle = profileInfo.handle;
      let authorName = profileInfo.name;
      let authorAvatar = profileInfo.avatar;

      const authorLink = container.querySelector('header a, a[role="link"][href^="/"]');
      if (authorLink) {
        const href = authorLink.getAttribute('href') || '';
        const handle = href.replace(/\//g, '').split('?')[0];
        if (handle && !['explore', 'reels', 'direct', 'stories'].includes(handle)) {
          authorHandle = `@${handle}`;
          authorName = authorLink.textContent?.trim() || handle;
        }
      }

      const avatarImg = container.querySelector('header img, img[alt*="perfil"], img[alt*="profile"]');
      if (avatarImg) {
        authorAvatar = avatarImg.getAttribute('src') || '';
      }

      let caption = '';
      const captionEl = container.querySelector('h1, span._ap3a, div[class*="caption"], div[class*="Description"]');
      if (captionEl) {
        caption = captionEl.textContent?.trim() || '';
      }

      let likes = 0;
      let comments = 0;

      const likesEl = container.querySelector('a[href*="/liked_by/"] span, a[href*="liked_by"], section button[type="button"] span, span[class*="html-span"]');
      if (likesEl) {
        likes = parseMetricNumber(likesEl.textContent);
      }
      if (!likes) {
        const allSpans = Array.from(container.querySelectorAll('span, a, div'));
        for (const sp of allSpans) {
          const txt = sp.textContent || '';
          if ((txt.includes('curtida') || txt.includes('curtidas') || txt.includes('like') || txt.includes('likes')) && /\d/.test(txt)) {
            likes = parseMetricNumber(txt);
            if (likes > 0) break;
          }
        }
      }

      const commentsEls = container.querySelectorAll('ul li, div[role="button"][tabindex="0"]');
      if (commentsEls.length > 1) {
        comments = commentsEls.length - 1;
      }
      const commentCountEl = container.querySelector('a[href*="/comments/"] span, span:contains("comentário")');
      if (commentCountEl) {
        const parsed = parseMetricNumber(commentCountEl.textContent);
        if (parsed > comments) comments = parsed;
      }

      const isVideo = !!video;
      const isCarousel = !!container.querySelector('div[aria-label*="carrossel"], div[aria-label*="carousel"], ul[class*="carousel"]');

      let thumbUrl = '';
      if (video) {
        thumbUrl = video.getAttribute('poster') || '';
      }
      if (!thumbUrl) {
        const img = container.querySelector('div[role="dialog"] img, article img');
        thumbUrl = img?.currentSrc || img?.src || '';
      }

      return {
        url: currentUrl,
        videoUrl: video ? (video.src || video.querySelector('source')?.src || currentUrl) : currentUrl,
        thumbnailUrl: thumbUrl,
        duration: video ? Math.round(video.duration || 15) : 15,
        authorName,
        authorHandle,
        authorAvatar,
        originalCaption: caption,
        platform: 'instagram',
        type: isVideo ? 'reel' : isCarousel ? 'carousel' : 'post',
        metrics: {
          likes,
          comments,
          views: likes * 5 || 1000
        }
      };
    } catch {
      return null;
    }
  }

  // Multi-Layer Universal Scanner for ALL posts on Profile Grid, Explore, Feed, or Search
  function scanAndAccumulateGridPosts() {
    const profileInfo = getPageProfileInfo();

    // ── LAYER 1: Scan ALL <a> tags on page ──
    const allAnchors = Array.from(document.querySelectorAll('a'));
    
    allAnchors.forEach((a) => {
      const rawHref = a.getAttribute('href') || a.href || '';
      if (!rawHref) return;

      // Filter only post or reel links
      if (!rawHref.includes('/p/') && !rawHref.includes('/reel/') && !rawHref.includes('/reels/') && !rawHref.includes('/tv/')) {
        return;
      }

      const cleanPath = rawHref.split('?')[0].split('#')[0];
      const match = cleanPath.match(/\/(p|reel|reels|tv)\/([A-Za-z0-9_-]+)/);
      if (!match) return;

      const postTypeKey = match[1];
      const shortcode = match[2];
      const fullUrl = `https://www.instagram.com/${postTypeKey === 'reels' ? 'reel' : postTypeKey}/${shortcode}/`;

      // Extract Thumbnail
      let thumbUrl = '';
      const img = a.querySelector('img') || a.parentElement?.querySelector('img');
      if (img) {
        thumbUrl = img.currentSrc || img.src || img.getAttribute('src') || '';
        if (!thumbUrl && img.getAttribute('srcset')) {
          thumbUrl = img.getAttribute('srcset').split(',')[0].split(' ')[0];
        }
      }
      if (!thumbUrl) {
        const bgDiv = a.querySelector('div[style*="background-image"]');
        if (bgDiv) {
          const m = bgDiv.style.backgroundImage.match(/url\(["']?([^"']+)["']?\)/);
          if (m) thumbUrl = m[1];
        }
      }

      const caption = img?.getAttribute('alt') || a.getAttribute('aria-label') || '';

      const isReel = postTypeKey.includes('reel') || !!a.querySelector('svg[aria-label*="Reel"], svg[aria-label*="Vídeo"], svg[aria-label*="Clip"], svg[aria-label*="Reels"]');
      const isCarousel = !!a.querySelector('svg[aria-label*="Carrossel"], svg[aria-label*="Carousel"], svg[aria-label*="Publicação com várias"]');
      const postType = isReel ? 'reel' : isCarousel ? 'carousel' : 'post';

      let likes = 0;
      let comments = 0;
      let views = 0;

      const ariaLabel = a.getAttribute('aria-label') || caption;
      if (ariaLabel) {
        const likeMatch = ariaLabel.match(/([\d\.,kKmM]+)\s*(?:curtidas|likes)/i);
        if (likeMatch) likes = parseMetricNumber(likeMatch[1]);

        const commentMatch = ariaLabel.match(/([\d\.,kKmM]+)\s*(?:comentários|comments)/i);
        if (commentMatch) comments = parseMetricNumber(commentMatch[1]);

        const viewMatch = ariaLabel.match(/([\d\.,kKmM]+)\s*(?:visualizações|views|reproduções)/i);
        if (viewMatch) views = parseMetricNumber(viewMatch[1]);
      }

      const listItems = a.querySelectorAll('ul li, div[class*="Overlay"] span, span[class*="html-span"]');
      if (listItems.length >= 1 && likes === 0) {
        likes = parseMetricNumber(listItems[0]?.textContent);
      }
      if (listItems.length >= 2 && comments === 0) {
        comments = parseMetricNumber(listItems[1]?.textContent);
      }

      if (views === 0) {
        views = (likes * 4) + (comments * 15);
      }

      const postData = {
        url: fullUrl,
        videoUrl: fullUrl,
        thumbnailUrl: thumbUrl,
        duration: isReel ? 15 : 0,
        authorName: profileInfo.name,
        authorHandle: profileInfo.handle,
        authorAvatar: profileInfo.avatar,
        originalCaption: caption,
        platform: 'instagram',
        type: postType,
        metrics: {
          likes,
          comments,
          views: views || (likes * 4) || 100
        }
      };

      accumulatedSessionPosts.set(fullUrl, postData);
    });

    // ── LAYER 2: Scan all images inside main / article whose ancestor is a link ──
    const gridImgs = document.querySelectorAll('main img, article img, div[role="main"] img');
    gridImgs.forEach((img) => {
      const parentLink = img.closest('a');
      if (parentLink) {
        const href = parentLink.getAttribute('href') || parentLink.href || '';
        if (href && (href.includes('/p/') || href.includes('/reel/'))) {
          const cleanPath = href.split('?')[0];
          const fullUrl = cleanPath.startsWith('http') ? cleanPath : `https://www.instagram.com${cleanPath.startsWith('/') ? '' : '/'}${cleanPath}`;
          if (!accumulatedSessionPosts.has(fullUrl)) {
            accumulatedSessionPosts.set(fullUrl, {
              url: fullUrl,
              videoUrl: fullUrl,
              thumbnailUrl: img.currentSrc || img.src || '',
              duration: href.includes('/reel/') ? 15 : 0,
              authorName: profileInfo.name,
              authorHandle: profileInfo.handle,
              authorAvatar: profileInfo.avatar,
              originalCaption: img.getAttribute('alt') || '',
              platform: 'instagram',
              type: href.includes('/reel/') ? 'reel' : 'post',
              metrics: { likes: 0, comments: 0, views: 0 }
            });
          }
        }
      }
    });

    return Array.from(accumulatedSessionPosts.values());
  }

  // Real-time Listeners
  window.addEventListener('scroll', () => {
    scanAndAccumulateGridPosts();
  }, { passive: true });

  setTimeout(scanAndAccumulateGridPosts, 500);
  setInterval(scanAndAccumulateGridPosts, 2500);

  // Auto-Miner: Smooth Scroll & Collection
  function startAutoMiner(targetCount = 48) {
    if (isAutoMining) return;
    isAutoMining = true;

    showToast(`Iniciando auto-mineração (alvo: ${targetCount} posts)...`);

    let scrollAttempts = 0;
    const maxAttempts = 25;

    autoMineInterval = setInterval(() => {
      window.scrollBy({ top: 1100, behavior: 'smooth' });
      scanAndAccumulateGridPosts();
      scrollAttempts++;

      const currentTotal = accumulatedSessionPosts.size;

      if (currentTotal >= targetCount || scrollAttempts >= maxAttempts) {
        stopAutoMiner();
        showToast(`Auto-mineração concluída: ${currentTotal} posts coletados!`);
      }
    }, 650);
  }

  function stopAutoMiner() {
    isAutoMining = false;
    if (autoMineInterval) {
      clearInterval(autoMineInterval);
      autoMineInterval = null;
    }
  }

  function injectButtons() {
    try {
      const dialog = document.querySelector('div[role="dialog"]');
      if (dialog) {
        if (!dialog.querySelector('.dark-clips-inject-btn')) {
          const btn = createFloatingButton(() => {
            const data = extractModalPostData(dialog);
            if (data) sendToDarkClips(data, btn);
          });
          btn.style.position = 'absolute';
          btn.style.top = '16px';
          btn.style.right = '56px';
          btn.style.zIndex = '9999999';

          // Prefer appending to inner modal container (article or main card) so Instagram knows the click is INSIDE the modal
          const innerCard = dialog.querySelector('article') || dialog.querySelector('div > div > div') || dialog;
          const computedPos = window.getComputedStyle(innerCard).position;
          if (computedPos === 'static') innerCard.style.position = 'relative';

          innerCard.appendChild(btn);
        }
        return;
      }

      const standaloneArticles = document.querySelectorAll('article:not([role="dialog"] article)');
      standaloneArticles.forEach((article) => {
        if (article.querySelector('.dark-clips-inject-btn')) return;

        const video = article.querySelector('video');
        if (!video) return;

        const btn = createFloatingButton(() => {
          const data = extractModalPostData(article);
          if (data) sendToDarkClips(data, btn);
        });
        btn.style.position = 'absolute';
        btn.style.top = '16px';
        btn.style.right = '16px';
        btn.style.zIndex = '9999999';

        const computedPos = window.getComputedStyle(article).position;
        if (computedPos === 'static') article.style.position = 'relative';

        article.appendChild(btn);
      });
    } catch {}
  }

  function createFloatingButton(onClick) {
    const btn = document.createElement('button');
    btn.className = 'dark-clips-inject-btn';
    btn.setAttribute('type', 'button');
    btn.innerHTML = `
      <svg class="dark-clips-icon" viewBox="0 0 24 24"><path d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
      <span>Dark Clips</span>
    `;

    // Intercept and stop ALL mouse/touch/pointer events in CAPTURE phase so Instagram backdrop handlers never see them
    const blockerEvents = ['pointerdown', 'pointerup', 'mousedown', 'mouseup', 'click', 'touchstart', 'touchend', 'focus'];
    blockerEvents.forEach((evt) => {
      btn.addEventListener(evt, (e) => {
        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();
        if (evt === 'click') {
          onClick();
        }
      }, true);
    });

    return btn;
  }

  setInterval(injectButtons, 1500);

  // Message listener for Extension Popup
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'GET_PAGE_VIDEOS') {
      scanAndAccumulateGridPosts();

      let videos = [];
      const seen = new Set();

      const dialog = document.querySelector('div[role="dialog"]');
      if (dialog) {
        const modalPost = extractModalPostData(dialog);
        if (modalPost) {
          seen.add(modalPost.url);
          videos.push(modalPost);
        }
      }

      accumulatedSessionPosts.forEach((post) => {
        if (!seen.has(post.url)) {
          seen.add(post.url);
          videos.push(post);
        }
      });

      if (videos.length === 0 && window.location.href.includes('/reel/')) {
        const profileInfo = getPageProfileInfo();
        videos.push({
          url: window.location.href,
          videoUrl: window.location.href,
          authorName: profileInfo.name,
          authorHandle: profileInfo.handle,
          platform: 'instagram',
          type: 'reel',
          metrics: { likes: 0, comments: 0, views: 0 }
        });
      }

      sendResponse({
        success: true,
        videos,
        totalAccumulated: accumulatedSessionPosts.size,
        profile: getPageProfileInfo()
      });
    } else if (request.action === 'START_AUTO_MINE') {
      const target = request.targetCount || 48;
      startAutoMiner(target);
      sendResponse({ success: true, isMining: true });
    } else if (request.action === 'STOP_AUTO_MINE') {
      stopAutoMiner();
      sendResponse({ success: true, isMining: false });
    }
  });

  console.log(`[${SCRIPT_NAME}] Ativo no Instagram (Multi-Layer Scanner & Auto-Miner Ready)!`);
})();
